
class Student:
    def __init__(self, sno, name, age, **kwargs):
        self.sno = sno
        self.name = name
        self.age = age
        self.keys = []
        self.values = []
        for i in kwargs.keys():
            self.keys.append(i)
        for j in kwargs.values():
            self.values.append(j)

    def __str__(self):
        str = "学号:{} 姓名:{} 年龄:{}".format(self.sno, self.name, self.age)
        for index, item in enumerate(self.keys):
            str += ",{}:{}".format(item, self.values[index])
        return str
