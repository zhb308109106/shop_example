"""
必须使用自定义函数，完成对程序的模块化
学生信息至少包含：姓名、年龄、学号，除此以外可以适当添加
必须完成的功能：添加、删除、修改、查询、退出

"""
from student import Student
import random

stuList = []


class StudentManage:

    def printmenu(self):
        str1 = "欢迎使用学生管理系统"
        print(str1.center(25, "*"))
        print("1.添加学生")
        print("2.删除学生")
        print("3.修改学生")
        print("4.查询学生")
        print("5.退出")
        print("*" * 25)

    def create_stu(self, student):
        if len(stuList) == 0:
            stuList.append(student)
        else:
            for stu in stuList:
                if student.sno == stu.sno:
                    print("此学号已经存在")
                    break
                else:
                    stuList.append(student)
                    break

    def del_stu(self, sno):
        for stu in stuList[::1]:
            if stu.sno == sno:
                stuList.remove(stu)
                break

    def update_stu(self, sno):
        for i in stuList:
            if i.sno == sno:
                name = input("请输入姓名:")
                age = input("请输入年龄:")
                for index, j in enumerate(i.keys):
                    i.values[index] = input("请输入{}:".format(j))
                i.name = name
                i.age = age
                break
        print("查无此人!!!")

    def show_stus(self):
        if len(stuList) > 0:
            for i in stuList:
                print(i)
        else:
            print("学生列表为空")


def main():
    stuManage = StudentManage()
    while True:
        stuManage.printmenu()
        action = input("请输入操作(1-5):")
        if action == "1":
            sno = random.randint(1000, 8889)
            name = input("请输入姓名:")
            age = input("请输入年龄:")
            dict1 = {}
            while True:
                shuxing = input("请输入自定义属性名(可选,不填按q或者回车退出):")
                if shuxing == "" or shuxing.lower() == "q":
                    break
                v = input("请输入自定义属性值:")
                dict1[shuxing] = v
            student = Student(sno, name, age, **dict1)
            stuManage.create_stu(student)
        elif action == "2":
            sno = int(input("请输入要删除的学生学号:"))
            stuManage.del_stu(sno)
        elif action == "3":
            sno = int(input("请输入要修改的学生学号:"))
            stuManage.update_stu(sno)
        elif action == "4":
            stuManage.show_stus()
        elif action == "5":
            exit()
        else:
            print("请输入正确的操作:(1-5):")


main()
